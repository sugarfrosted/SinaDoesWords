
def add_one(number):
    return number + 1

# import array
# from typing import TypeVar, Generic

# msg = "butts"

# OPERATOR_ARRITY = { "*" : 2, "-" : 1, "i" : 0, "j" : 0, "n" : 0, "e" : 0 }





#def baseSimplify(n, m):

# operatorSplit("*ij")

# print(msg)

# def thing(expression):
#     "*ab"

# def isValid(expression):
#     ""
    
# def operatorSplit(expression):
#     arr = array.array("w", expression)
#     operator = expression.pop(0)
#     arrity = operator.get(operator)

# class WordAlgebraFactory(Generic: T):
#     def __init__(self, arrity_list):
#         self.arrity_list
